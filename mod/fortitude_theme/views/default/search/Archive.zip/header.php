<?php
/**
 * Search box in page header
 */

echo elgg_view('search/search_box', array('class' => 'elgg-search-header'));