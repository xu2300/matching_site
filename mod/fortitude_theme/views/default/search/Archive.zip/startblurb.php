<?php
/**
 * @todo This doesn't appear to be called by anything. Look into removing.
 */

echo elgg_echo("tag:search:startblurb", array($vars['query']));
