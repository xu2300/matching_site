<?php
/**
 * No results from search
 */

echo elgg_autop(elgg_echo('search:no_results'));
